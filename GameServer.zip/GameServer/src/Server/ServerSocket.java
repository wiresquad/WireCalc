/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Server;

import UsersPackage.UserManager;
import java.io.*;
import java.net.*;
import sun.awt.windows.ThemeReader;

/**
 *
 * @author xguest
 */
public class ServerSocket {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DatagramSocket sock = null;
        UsersPackage.UserManager users=new UserManager();
                 
        try
        {
            //1. creating a server socket, parameter is local port number
            sock = new DatagramSocket(8080);
             
            //buffer to receive incoming data
            byte[] buffer = new byte[65536];
            DatagramPacket incoming = new DatagramPacket(buffer, buffer.length);
             
            //2. Wait for an incoming data
            echo("Server socket created. Waiting for incoming data...");
             
            //communication loop
            while(true)
            {
                sock.receive(incoming);
                (new Thread(new PacketResponser(users, sock, incoming))).start();
            }
        }
         
        catch(IOException e)
        {
            System.err.println("IOException " + e);
        }
    }
    
    //simple function to echo data to terminal
    public static void echo(String msg)
    {
        System.out.println(msg);
    }
}
